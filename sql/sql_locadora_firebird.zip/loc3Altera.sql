/* Conecta o banco de dados Locadora da Lista de Exerc�cios */
/* CONNECT "C:\ib\loc\gdb\loc.gdb" USER 'ADMEMP' PASSWORD 'adm01';*/

ALTER TABLE Cliente
      ADD FOREIGN KEY (idcliresp) REFERENCES Cliente(idcli);
ALTER TABLE Filme
      ADD FOREIGN KEY(idgen) REFERENCES Genero(idgen);
ALTER TABLE Filme
      ADD FOREIGN KEY(idprod) REFERENCES Produtora(idprod);
ALTER TABLE Fita
      ADD FOREIGN KEY(idfil) REFERENCES Filme(idfil);
ALTER TABLE Conta
      ADD FOREIGN KEY(idtpct) REFERENCES TipoConta(idtpct);
ALTER TABLE ContaLiq
      ADD FOREIGN KEY(idct) REFERENCES Conta(idct);
ALTER TABLE Locacao
      ADD FOREIGN KEY(idcli) REFERENCES Cliente(idcli);
ALTER TABLE Locacao
      ADD FOREIGN KEY(idct) REFERENCES Conta(idct);
ALTER TABLE ItemLoc
      ADD FOREIGN KEY(idloc) REFERENCES Locacao(idloc);
ALTER TABLE ItemLoc
      ADD FOREIGN KEY(idfil) REFERENCES Filme(idfil);
ALTER TABLE ItemLoc
      ADD FOREIGN KEY(idfil,ordfita) REFERENCES Fita(idfil,ordfita);
ALTER TABLE FilBaixa
      ADD FOREIGN KEY(idfil,ordfita) REFERENCES Fita(idfil,ordfita);
ALTER TABLE FilBaixa
      ADD FOREIGN KEY(idct) REFERENCES Conta(idct);
ALTER TABLE FilPart
      ADD FOREIGN KEY(idfil) REFERENCES Filme(idfil);
ALTER TABLE FilPart
      ADD FOREIGN KEY(idart) REFERENCES Artista(idart);
ALTER TABLE FilPart
      ADD FOREIGN KEY(idpart) REFERENCES Particip(idpart);

/* fim */
commit;
